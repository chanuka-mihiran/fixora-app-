# FIXORA Starter Prototype
Open `index.html` in a browser to preview the first UI demo.

This is only a front-end prototype. Jobs and demo account are stored in the browser's localStorage on the same device.
It does NOT yet include real authentication, Firebase/database syncing, NIC verification, real notifications, 50km matching, professional offers, or admin tools.
Do not enter real NIC or sensitive personal information.

Next: upload `index.html` to a GitHub repository and enable GitHub Pages to preview it online.
